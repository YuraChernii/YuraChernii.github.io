export const environment = {
  production: true,
  apiKey: "AIzaSyDI-dbSPY4M07Lu2prXtkgx0_aM38vADTc",
  fbDB:"https://angular-blog-203a7-default-rtdb.firebaseio.com"
};
